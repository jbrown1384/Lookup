CREATE DATABASE  IF NOT EXISTS `LookupApp` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `LookupApp`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: LookupApp
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address_customer`
--

DROP TABLE IF EXISTS `address_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_customer` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_customer`
--

LOCK TABLES `address_customer` WRITE;
/*!40000 ALTER TABLE `address_customer` DISABLE KEYS */;
INSERT INTO `address_customer` VALUES (1,24,1,NULL,NULL),(2,13,1,NULL,NULL),(3,1,2,NULL,NULL),(4,27,2,NULL,NULL),(5,24,3,NULL,NULL),(6,26,4,NULL,NULL),(7,28,4,NULL,NULL),(8,10,5,NULL,NULL),(9,6,5,NULL,NULL),(10,9,5,NULL,NULL),(11,12,6,NULL,NULL),(12,22,6,NULL,NULL),(13,20,7,NULL,NULL),(14,6,7,NULL,NULL),(15,21,7,NULL,NULL),(16,25,8,NULL,NULL),(17,9,8,NULL,NULL),(18,23,8,NULL,NULL),(19,8,9,NULL,NULL),(20,16,9,NULL,NULL),(21,24,9,NULL,NULL),(22,16,10,NULL,NULL),(23,25,10,NULL,NULL),(24,20,11,NULL,NULL),(25,9,11,NULL,NULL),(26,17,11,NULL,NULL),(27,24,12,NULL,NULL),(28,17,12,NULL,NULL),(29,22,12,NULL,NULL),(30,12,13,NULL,NULL),(31,11,13,NULL,NULL),(32,21,13,NULL,NULL),(33,12,14,NULL,NULL),(34,15,14,NULL,NULL),(35,2,15,NULL,NULL),(36,11,15,NULL,NULL),(38,9,16,NULL,NULL),(39,26,17,NULL,NULL),(40,24,18,NULL,NULL),(41,28,18,NULL,NULL),(42,2,18,NULL,NULL),(44,13,19,NULL,NULL),(45,4,20,NULL,NULL),(46,3,20,NULL,NULL),(47,16,20,NULL,NULL);
/*!40000 ALTER TABLE `address_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,'118 Klein Road Apt. 784','Noemihaven','Vermont','17729-0013','2020-01-12 22:43:41','2020-01-12 22:43:41'),(2,'913 Daphnee Rapids Suite 487','Michaleville','Montana','09133-8379','2020-01-12 22:43:41','2020-01-12 22:43:41'),(3,'45289 Mante Burg Suite 033','North Vedamouth','Michigan','21210','2020-01-12 22:43:41','2020-01-12 22:43:41'),(4,'59370 Fritsch Station Apt. 181','Jacobsmouth','Pennsylvania','08654-7493','2020-01-12 22:43:41','2020-01-12 22:43:41'),(5,'361 Michele Walk','East Colby','New Jersey','36145','2020-01-12 22:43:41','2020-01-12 22:43:41'),(6,'715 Neha Port','Port Laury','California','90970','2020-01-12 22:43:41','2020-01-12 22:43:41'),(7,'100 D\'Amore Fork Apt. 296','Creminborough','District of Columbia','57719-9639','2020-01-12 22:43:41','2020-01-12 22:43:41'),(8,'13760 Hermann Fall','Halvorsonmouth','Colorado','14673-4338','2020-01-12 22:43:41','2020-01-12 22:43:41'),(9,'9024 Dell Corner Apt. 896','Ramirofort','Nevada','36694-9602','2020-01-12 22:43:41','2020-01-12 22:43:41'),(10,'8119 Britney Alley','North Gissellebury','California','01879-9953','2020-01-12 22:43:41','2020-01-12 22:43:41'),(11,'44066 Wisoky Mountains','Bartellberg','Nevada','30967','2020-01-12 22:43:41','2020-01-12 22:43:41'),(12,'58167 Denesik Ville Suite 484','North Christellebury','Mississippi','94887','2020-01-12 22:43:41','2020-01-12 22:43:41'),(13,'82842 Freda River','North Maybellbury','Illinois','28086','2020-01-12 22:43:41','2020-01-12 22:43:41'),(14,'2823 Nicolas Passage Suite 632','West Kearafort','Iowa','33696-9943','2020-01-12 22:43:41','2020-01-12 22:43:41'),(15,'2485 Morissette Canyon','Lake Eltafurt','Oklahoma','82187','2020-01-12 22:43:41','2020-01-12 22:43:41'),(16,'42506 Stoltenberg Fields','North Erna','Nebraska','16185','2020-01-12 22:43:41','2020-01-12 22:43:41'),(17,'330 Burnice Alley Apt. 600','New Maymie','South Carolina','11946-6648','2020-01-12 22:43:41','2020-01-12 22:43:41'),(18,'715 Huel Valleys Suite 005','Gleasonmouth','Idaho','59584-5308','2020-01-12 22:43:41','2020-01-12 22:43:41'),(19,'573 Braun Plains Apt. 930','Agnesberg','North Carolina','55131','2020-01-12 22:43:41','2020-01-12 22:43:41'),(20,'5246 Eldon Land','Port Myrtie','Virginia','66154','2020-01-12 22:43:41','2020-01-12 22:43:41'),(21,'1058 Ada Glen Apt. 886','Rachellestad','Colorado','68602','2020-01-12 22:43:41','2020-01-12 22:43:41'),(22,'8670 Dibbert Street','Lutherborough','Oregon','49704-7716','2020-01-12 22:43:41','2020-01-12 22:43:41'),(23,'3762 Adelle Meadows Apt. 648','Bogisichstad','Ohio','14394-0108','2020-01-12 22:43:41','2020-01-12 22:43:41'),(24,'781 Mia Ville','Santiagofurt','Kansas','01749-4019','2020-01-12 22:43:41','2020-01-12 22:43:41'),(25,'993 Samson Turnpike Apt. 571','Kentonside','District of Columbia','30228','2020-01-12 22:43:41','2020-01-12 22:43:41'),(26,'9489 Schroeder Heights','Lake Monserrate','Kentucky','74855-8543','2020-01-12 22:43:41','2020-01-12 22:43:41'),(27,'627 Vena Landing','Abshirebury','Maryland','95030-5538','2020-01-12 22:43:41','2020-01-12 22:43:41'),(28,'37720 Adams Vista','North Scarlett','Vermont','00273-8220','2020-01-12 22:43:41','2020-01-12 22:43:41'),(29,'396 Syble Mill','West Ervin','Kentucky','96395-9861','2020-01-12 22:43:41','2020-01-12 22:43:41'),(30,'238 Gonzalo Trace','New Amaya','Idaho','46505','2020-01-12 22:43:41','2020-01-12 22:43:41');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_role`
--

DROP TABLE IF EXISTS `customer_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_role`
--

LOCK TABLES `customer_role` WRITE;
/*!40000 ALTER TABLE `customer_role` DISABLE KEYS */;
INSERT INTO `customer_role` VALUES (2,1,2,NULL,NULL),(5,1,5,NULL,NULL),(6,1,1,NULL,NULL),(7,1,3,NULL,NULL),(10,2,3,NULL,NULL),(12,2,1,NULL,NULL),(13,2,4,NULL,NULL),(16,3,3,NULL,NULL),(17,3,1,NULL,NULL),(19,4,5,NULL,NULL),(22,5,2,NULL,NULL),(24,6,5,NULL,NULL),(28,6,1,NULL,NULL),(31,7,1,NULL,NULL),(35,8,3,NULL,NULL),(36,8,5,NULL,NULL),(37,8,1,NULL,NULL),(40,9,1,NULL,NULL),(41,9,2,NULL,NULL),(43,10,2,NULL,NULL),(46,10,4,NULL,NULL),(47,10,1,NULL,NULL),(51,11,2,NULL,NULL),(52,11,1,NULL,NULL),(53,11,3,NULL,NULL),(56,12,1,NULL,NULL),(57,12,2,NULL,NULL),(59,13,2,NULL,NULL),(60,13,4,NULL,NULL),(63,14,1,NULL,NULL),(64,14,5,NULL,NULL),(66,15,3,NULL,NULL),(68,15,2,NULL,NULL),(69,15,4,NULL,NULL),(72,16,4,NULL,NULL),(73,16,5,NULL,NULL),(74,16,1,NULL,NULL),(77,17,4,NULL,NULL),(79,17,1,NULL,NULL),(82,18,4,NULL,NULL),(83,18,1,NULL,NULL),(84,19,1,NULL,NULL),(86,20,2,NULL,NULL),(87,20,4,NULL,NULL);
/*!40000 ALTER TABLE `customer_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Spencer Jaskolski PhD','male','1981-01-16','2020-01-12 22:43:50','2020-01-12 22:43:50'),(2,'Lexus Zulauf','male','2019-08-21','2020-01-12 22:43:50','2020-01-12 22:43:50'),(3,'Mrs. Jennifer Quigley','male','2006-01-09','2020-01-12 22:43:50','2020-01-12 22:43:50'),(4,'Gregory Kertzmann','female','2010-07-02','2020-01-12 22:43:50','2020-01-12 22:43:50'),(5,'Ms. Lucy Kuhic PhD','female','1975-04-05','2020-01-12 22:43:50','2020-01-12 22:43:50'),(6,'Martine Dickinson','female','1988-07-08','2020-01-12 22:43:51','2020-01-12 22:43:51'),(7,'Nathan Mayer','male','2006-01-19','2020-01-12 22:43:51','2020-01-12 22:43:51'),(8,'Kristin Nolan MD','female','1993-05-06','2020-01-12 22:43:51','2020-01-12 22:43:51'),(9,'Prof. Darrell Boehm II','male','1973-06-23','2020-01-12 22:43:51','2020-01-12 22:43:51'),(10,'Miss Stacey Williamson','female','2001-12-19','2020-01-12 22:43:51','2020-01-12 22:43:51'),(11,'George Osinski','female','1983-05-26','2020-01-12 22:43:51','2020-01-12 22:43:51'),(12,'Tiana Kilback IV','female','1996-11-02','2020-01-12 22:43:51','2020-01-12 22:43:51'),(13,'Mina Rogahn DVM','male','1973-03-03','2020-01-12 22:43:51','2020-01-12 22:43:51'),(14,'Margaret Jerde','male','1983-07-03','2020-01-12 22:43:51','2020-01-12 22:43:51'),(15,'Prof. Katelin Carter','male','1987-11-07','2020-01-12 22:43:51','2020-01-12 22:43:51'),(16,'Thomas Moen','female','1980-05-06','2020-01-12 22:43:51','2020-01-12 22:43:51'),(17,'Casimer Dooley','female','2006-09-04','2020-01-12 22:43:51','2020-01-12 22:43:51'),(18,'Lorna Erdman','female','1990-04-09','2020-01-12 22:43:52','2020-01-12 22:43:52'),(19,'Eldora Olson','female','1978-04-03','2020-01-12 22:43:52','2020-01-12 22:43:52'),(20,'Mr. Nolan Walter','female','1970-12-10','2020-01-12 22:43:52','2020-01-12 22:43:52');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (17,'2014_10_12_000000_create_users_table',1),(18,'2014_10_12_100000_create_password_resets_table',1),(19,'2019_08_19_000000_create_failed_jobs_table',1),(20,'2020_01_12_182852_create_customers_table',1),(21,'2020_01_12_192540_create_roles_table',1),(22,'2020_01_12_205238_create_customer_role_pivot_table',1),(23,'2020_01_12_215947_create_addresses_table',1),(24,'2020_01_12_220830_create_address_customer_pivot_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin',1,NULL,NULL),(2,'contributor',1,NULL,NULL),(3,'editor',1,NULL,NULL),(4,'viewer',1,NULL,NULL),(5,'billing',1,NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'LookupApp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-12 19:57:11
